import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  Linking,
  ScrollView,
  TouchableOpacity,
  ImageBackground,
  Dimensions,
} from 'react-native';

const { width } = Dimensions.get('window');

export default function App() {
  const openLink = (url) => {
    Linking.openURL(url).catch(() => alert('Failed to open link'));
  };

  return (
    <ImageBackground
      source={{ uri: 'https://i.imgur.com/nvX6mAu.jpg' }} // Blue Lotus water/light background
      style={styles.background}
      blurRadius={20}
    >
      <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <Text style={styles.title}>Rising Dawn</Text>
        <Text style={styles.subtitle}>The Blue Lotus Ministries App</Text>

        {/* Welcome */}
        <View style={styles.welcomeCard}>
          <Text style={styles.welcomeText}>
            Welcome to Blue Lotus Ministries Inc. Uplifting our community through faith, outreach, and empowerment.
          </Text>
        </View>

        {/* Link Cards */}
        <View style={styles.linksContainer}>
          <LinkCard
            title="Website"
            subtitle="Visit Our Website"
            onPress={() => openLink('https://bluelotusministriesinc.neocities.org/')}
          />
          <LinkCard
            title="Facebook"
            subtitle="Follow us on Facebook"
            onPress={() => openLink('https://www.facebook.com/bluelotusministriesinc')}
          />
          <LinkCard
            title="Twitter"
            subtitle="Follow us on Twitter"
            onPress={() => openLink('https://twitter.com/BlueLotusMin')}
          />
          <LinkCard
            title="Instagram"
            subtitle="Follow us on Instagram"
            onPress={() => openLink('https://instagram.com/bluelotusministriesinc')}
          />
          <LinkCard
            title="Podcast"
            subtitle="Listen on Spotify"
            onPress={() => openLink('https://open.spotify.com/show/6hesDZPrJyJ5YrMBH60mgp')}
          />
          <LinkCard
            title="Email Us"
            subtitle="thomasesp2021@gmail.com"
            onPress={() => openLink('mailto:thomasesp2021@gmail.com')}
          />
          <LinkCard
            title="Call Us"
            subtitle="678-978-1741"
            onPress={() => openLink('tel:+16789781741')}
          />
        </View>

        {/* Footer */}
        <Text style={styles.footer}>© 2025 Blue Lotus Ministries Inc.</Text>
      </ScrollView>
    </ImageBackground>
  );
}

function LinkCard({ title, subtitle, onPress }) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.8}>
      <Text style={styles.cardTitle}>{title}</Text>
      <Text style={styles.cardSubtitle}>{subtitle}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  container: {
    paddingVertical: 40,
    paddingHorizontal: 25,
    alignItems: 'center',
  },
  title: {
    fontSize: 42,
    fontWeight: '900',
    color: '#E6E6FA',
    textShadowColor: '#553577',
    textShadowOffset: { width: 0, height: 3 },
    textShadowRadius: 10,
    marginBottom: 5,
    fontFamily: 'Helvetica',
  },
  subtitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#D8BFD8',
    marginBottom: 30,
    fontFamily: 'Helvetica',
  },
  welcomeCard: {
    backgroundColor: 'rgba(50, 0, 70, 0.65)',
    borderRadius: 20,
    padding: 25,
    marginBottom: 35,
    shadowColor: '#7A3EB5',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.9,
    shadowRadius: 20,
    elevation: 14,
    width: width - 50,
  },
  welcomeText: {
    fontSize: 18,
    color: '#EDE6F7',
    lineHeight: 26,
    textAlign: 'center',
    fontWeight: '600',
  },
  linksContainer: {
    width: width - 50,
  },
  card: {
    backgroundColor: 'rgba(120, 70, 180, 0.85)',
    borderRadius: 30,
    paddingVertical: 20,
    paddingHorizontal: 25,
    marginBottom: 18,
    shadowColor: '#8C52FF',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.7,
    shadowRadius: 15,
    elevation: 10,
  },
  cardTitle: {
    color: '#F4E9FF',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 4,
    textShadowColor: '#471D7A',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
  },
  cardSubtitle: {
    color: '#DCC6FF',
    fontSize: 16,
    fontWeight: '600',
    textShadowColor: '#4E2683',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 6,
  },
  footer: {
    marginTop: 40,
    fontSize: 14,
    fontWeight: '600',
    color: '#C7B6F4',
    textAlign: 'center',
    textShadowColor: '#3A2077',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 5,
  },
});